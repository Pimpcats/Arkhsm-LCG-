-- Objective [action]s and the finale (The Last Hour): its setup from the
-- guide, contest progress, and the finale resolutions.

return function(R, T)
  local E = T.E
  local FX = R.FX

  ------------------------------------------------------------ objective actions --

  --- Light the Lamp, The Wheel Still Turns, The Ticket-Taker's Bargain.
  function R.objectiveAction(inv, act)
    local G = R.G
    local spec = FX.ACTS[act.id]
    local L = R.locById(spec.at)
    if R.locOf(inv) ~= L then return false end
    local need = FX.actNeed(act.id)
    local here = spec.contrib == false and R.aliveInvs() or R.investigatorsAt(L)
    if spec.fare then
      -- the Ticket-Taker's fare: resources (FX.FARE_RATE for 1) first, then clues, then Memory on own cards
      local owe = need
      local rate = (R.WHATIF or {}).fareRate or FX.FARE_RATE or 2     -- resources per fare point
      local available = 0
      for _, x in ipairs(here) do available = available + x.clues + math.floor(x.resources / rate) + R.syncMemory(x) end
      if available < need then return false end
      for _, x in ipairs(here) do
        while owe > 0 and x.resources >= rate and x.resources >= 2 * rate do x.resources = x.resources - rate ; owe = owe - 1 end
      end
      local cl = 0
      for _, x in ipairs(here) do cl = cl + x.clues end
      local pay = math.min(owe, cl)
      if pay > 0 then R.spendClues(here, pay) ; owe = owe - pay end
      for _, x in ipairs(here) do
        while owe > 0 and (x.memory or 0) > 0 do R.addMemory(x, -1, "the Ticket-Taker's fare", "any") ; owe = owe - 1 end
      end
      for _, x in ipairs(here) do
        while owe > 0 and x.resources >= rate do x.resources = x.resources - rate ; owe = owe - 1 end
      end
      if owe ~= 0 then error("fare preflight/payment disagreement") end
      R.advanceAct(act, inv)
      return true
    end
    R.spendClues(here, need)
    if spec.doomCost then R.placeDoom(spec.doomCost, act.id .. " (cost)") end
    if spec.test then
      local skill, best = spec.test[1], -99
      for _, s in ipairs(spec.test) do
        local v = R.skillBase(inv, s) + R.P.staticBonus(inv, s, {})
        if v > best then skill, best = s, v end
      end
      local ok = R.test(inv, skill, spec.diff, { kind = "act", important = true, target = 0.8 })
      if ok then
        R.advanceAct(act, inv)
      elseif spec.failClues then
        -- place 1 [perinv] clues from the token pool on the location
        T.spawnClueOn(L.obj, need)
        G.metrics.objective_fails = (G.metrics.objective_fails or 0) + 1
      end
    else
      R.advanceAct(act, inv)
    end
  end

  --- Who Walks Beside You's clue cost: the act's clues (what-if walksBesideClues [perinv])
  function R.walksBesideCost()
    local w = (R.WHATIF or {}).walksBesideClues
    if w then return w * R.G.n end
    local c = R.card("sthr-act-walksbeside") or {}
    return (c.clues or 0) * (c.clues_per_investigator and R.G.n or 1)
  end
  local function cluesAt(L)
    local have = 0
    for _, x in ipairs(R.investigatorsAt(L)) do have = have + x.clues end
    return have
  end

  --- Who Walks Beside You: Stand Firm against a ready Echo at the Turning.
  -- With a clue cost, the investigators there spend it first; a failed test
  -- puts the clues on the Turning (as the Lamp and the Wheel do).
  function R.standFirm(inv, en)
    local L = R.locOf(inv)
    local need = R.walksBesideCost()
    if need > 0 then
      if cluesAt(L) < need then return end
      R.spendClues(R.investigatorsAt(L), need)
    end
    local x = R.enemyFight(en)
    local skill = (R.skillBase(inv, "wil") >= R.skillBase(inv, "com")) and "wil" or "com"
    local ok = R.test(inv, skill, x, { kind = "act", important = true })
    if ok then
      en.exhausted = true
      en.engaged = nil
      R.placeEnemy(en)
      local act = R.G.acts.Road
      if act and act.id == "sthr-act-walksbeside" then R.advanceAct(act, inv) end
    elseif need > 0 then
      T.spawnClueOn(L.obj, need)
      R.G.metrics.objective_fails = (R.G.metrics.objective_fails or 0) + 1
    end
  end

  function FX.onEvade(inv, en)
    local G = R.G
    local L = G.locs[en.loc]
    if G.walksBesideCurrent and L and L.id == "sthr-loc-turning" and R.hasTrait(en.def, "Echo") then
      local act = G.acts.Road
      if act and act.id == "sthr-act-walksbeside" and not act.completed then
        local need = R.walksBesideCost()
        if need > 0 then
          if cluesAt(L) < need then return end
          R.spendClues(R.investigatorsAt(L), need)
        end
        G.walksBesideCurrent = false
        R.advanceAct(act, inv)
      end
    end
  end

  ------------------------------------------------------------ the finale --

  local DEEP = { "the-keepers-ninth-death", "the-hour-was-wrong", "who-walks-beside-you", "the-vote-that-never-ends",
                 "the-ticket-takers-bargain", "the-appointeds-name" }

  --- [free] at the Sealed Study: begin the finale (guide: The Last Hour, Setup).
  function R.beginFinale(inv, atNine)
    local G = R.G
    if G.finale then return end
    G.finale = true
    -- Participation is fixed when the finale starts. Later defeat does not
    -- remove an investigator from its resolution (player guide, The Last Hour).
    G.finaleParticipants = {}
    for _, x in ipairs(R.aliveInvs()) do G.finaleParticipants[x.id] = true end
    G.metrics.finale_began = { round = G.round, hour = R.hour(), dissonance = R.dissonance(), atNine = atNine and true or false }
    R.log("THE FINALE BEGINS (Hour %d, Dissonance %d)", R.hour(), R.dissonance())
    -- 1. Place The Last Hour; district act decks are set aside
    for d, act in pairs(G.acts) do
      local c = T.cardWithId(act.id)
      if c then c.setPosition({ -60, 2, -12 }) end
    end
    G.actsBeforeFinale = G.acts
    G.acts, G.actOrder = {}, {}
    local box = T.placeBox("finale")
    E.run(1)
    local unv = T.takeCard("sthr-uninvited")
    -- 2. the Approach advances to Arrived (it manifests if set aside)
    local guard = 0
    while R.stage() < 3 and guard < 4 do
      guard = guard + 1
      T.ctl("Appointed")
      E.run(0.3)
      R.touch()
    end
    R.syncAppointedArrival()
    -- begun at Hour IX: Hours IX to VI go back on the deck, Hour V is current,
    -- no Hour resolves (right-click Hour four times)
    if atNine then R.rewind(4, "the finale begins at Hour IX") end
    -- a finale begun before Hour V skips to Hour V (each Hour resolves):
    -- advance until Hour V is current rather than a fixed number of clicks.
    local fromHour = (R.WHATIF or {}).finaleFrom or 5
    if not atNine then
      local guard = 0
      while R.hour() < fromHour and not G.ended and guard < 9 do
        guard = guard + 1
        R.advance(1, "the finale begins")
      end
    end
    -- the Uninvited at the revealed location farthest from all investigators, not closed
    if unv then
      local far, fd
      for _, L in ipairs(G.locList) do
        if L.revealed and not L.closed then
          local d = 99
          for _, x in ipairs(R.aliveInvs()) do
            local dist = R.paths(R.locOf(x), { enemy = true })[L.guid] or 99
            if dist < d then d = dist end
          end
          if fd == nil or d > fd then far, fd = L, d end
        end
      end
      if R.FINALE_SPAWN_AT then far = R.locById(R.FINALE_SPAWN_AT) or far end     -- what-if only
      if (R.WHATIF or {}).uninvitedAt then far = R.locById(R.WHATIF.uninvitedAt) or far end   -- what-if only
      R.spawnEnemy(unv, far, nil, { want = "the revealed location farthest from all investigators" })
    end
    -- 3. Begin Finale on the Control: the Contest counter
    T.ctl("Begin Finale")
    E.run(0.3)
    R.touch()
    if R.FINALE_SPAWN_AT or (R.WHATIF or {}).finaleAppointedAt then      -- what-if only
      local L = R.locById(R.FINALE_SPAWN_AT or R.WHATIF.finaleAppointedAt)
      if L then R.placeAppointed(L) end
    end
    local AL = R.appointedLoc()
    G.metrics.finale_appointed_at = AL and AL.id or "?"
    R.log("The Appointed is at %s at the start of the finale", AL and AL.name or "?")
    if G.logFlags["You have spoken the name"] then R.contest((R.WHATIF or {}).spokenValue or 1, "You have spoken the name") end
    if G.logFlags["The drowned heard the true hour"] then R.rewind(1, "The drowned heard the true hour") end
    G.nameUnspoken = G.logFlags["The name is kept unspoken"]
    -- what-if: each investigator heals when the finale begins ({damage, horror})
    local fh = (R.WHATIF or {}).finaleHeal
    if fh then
      for _, x in ipairs(R.aliveInvs()) do
        R.heal(x, math.min(fh[1] or 0, x.damage), math.min(fh[2] or 0, x.horror))
      end
    end
    G.deepToSpend = {}
    for _, f in ipairs(DEEP) do if R.knows(f) then G.deepToSpend[#G.deepToSpend + 1] = f end end
    -- the first time each investigator is at the Sealed Study (those already there gain it now)
    local study = R.locById("sthr-loc-sealedstudy")
    for _, x in ipairs(R.aliveInvs()) do
      if study and x.loc == study.guid and not G.studyVisited[x.id] and (R.WHATIF or {}).studyVisits then
        G.studyVisited[x.id] = true
        R.contest(1, "first time at the Sealed Study")
      end
    end
  end

  --- [action] on Contest the Crossing: spend a deep Knowledge entry.
  function R.spendDeep(inv)
    local G = R.G
    local f = table.remove(G.deepToSpend, 1)
    if f then
      G.metrics.deep_spent = (G.metrics.deep_spent or 0) + 1
      R.contest(1, "deep entry spent: " .. f)
    end
  end

  --- The finale resolution the party reads (it chooses among those it meets).
  function R.finaleResolution()
    local G = R.G
    local n = G.n
    local reached = G.contest >= R.consts().contest
    local banked = T.st().memory or 0
    if not reached then
      return banked >= 4 * n and "R5" or "R6"
    end
    local present = {}
    for _, inv in ipairs(G.inv) do
      if G.finaleParticipants and G.finaleParticipants[inv.id]
         or not G.finaleParticipants and not inv.defeated then
        present[#present + 1] = inv
      end
    end
    local lf = G.logFlags
    if R.knows("the-keepers-ninth-death") then return "R3" end
    if R.knows("the-ticket-takers-bargain") and lf["You hold the ticket"]
       and banked >= (lf["You kept the night to yourselves"] and 3 or 4) * n then return "R1b" end
    if R.knows("the-vote-that-never-ends") and R.knows("the-appointeds-name") and lf["The vote still stands"] then return "R2" end
    for _, inv in ipairs(present) do
      -- Pending Years count for ending eligibility without changing the aged
      -- stat line during play. Every real investigator has recorded years;
      -- retain the bracket fallback only for older isolated fixtures.
      if (inv.years or 0) + (inv.pendingYears or 0) >= 15
         or inv.years == nil and inv.bracket == "Ancient" then return "R1" end
    end
    return "R4"
  end
end
