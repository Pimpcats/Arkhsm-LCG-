-- Designer-only verification. Modules execute against in-memory fixtures.
local cache={}
function require(name)
  if cache[name] then return cache[name] end
  cache[name]=assert(loadfile("src/"..name..".ttslua"))()
  return cache[name]
end
local CS=require("StillHour/CampaignState")
local D=require("StillHour/Dissonance")
local Bag=require("StillHour/ChaosBag")
local L=require("StillHour/Locations")
local Board=require("StillHour/Board")
local checks=0
local function check(name,cond)
 assert(cond,name)
 checks=checks+1
 print("PASS "..name)
end
local container={getName=function() return "Chaos Bag" end}
local token={hasTag=function(tag) return tag==Bag.TOKEN_TAG end,getGUID=function() return "static01" end}
for _, start in ipairs({7,15,23}) do
 CS.init(3);CS.setDissonanceRaw(start)
 local bag=Bag.new()
 check("pending Static extraction "..start,bag.onLeave(container,token))
 check("duplicate extraction ignored "..start,not bag.onLeave(container,token))
 check("preview has no campaign consequences "..start,CS.getDissonance()==start and CS.getAppointedStage()==0)
 check("return cancels pending reveal "..start,bag.onEnter(container,token) and bag.takePendingStatic()==nil)
 check("returned preview retains meter and stage "..start,CS.getDissonance()==start and CS.getAppointedStage()==0)
 check("new genuine draw queues "..start,bag.onLeave(container,token))
 check("explicit canceled draw consumed "..start,bag.takePendingStatic()=="static01")
 check("second consume is inert "..start,bag.takePendingStatic()==nil)
 check("canceled draw retains meter and stage "..start,CS.getDissonance()==start and CS.getAppointedStage()==0)
end
CS.init(3);CS.setDissonanceRaw(7)
local b=Bag.new(); b.onLeave(container,token)
local guid=b.takePendingStatic()
if guid then D.onStaticRevealed() end
check("resolved Static advances exactly once",CS.getDissonance()==8 and CS.getAppointedStage()==1)
check("resolved Static cannot be consumed twice",b.takePendingStatic()==nil)
CS.init(3);CS.setPrologue(true);CS.addPendingYears("sthrelias",1);CS.reset()
check("Prologue reset discards pending Years",CS.getPendingYears("sthrelias")==0 and CS.getLoopsCompleted()==0)
local graph={Square={"Steps","Milestones"},Steps={"Square"},Milestones={"Square","Bridge"},Bridge={"Milestones","Turning"},Turning={"Bridge","Stair"},Stair={"Turning","Lantern"},Lantern={"Stair"}}
local dest,dist,ties=L.farthest(graph,{"Square"},nil,{Square=true,Steps=true,Lantern=true})
check("unrevealed transit retained with revealed endpoint filter",dest=="Lantern" and dist==5 and #ties==1)
local closedGraph={Square={"Steps","Milestones"},Steps={"Square"},Milestones={"Square"},Turning={"Stair"},Stair={"Turning","Lantern"},Lantern={"Stair"}}
local c,d=L.farthest(closedGraph,{"Square"},nil,{Square=true,Steps=true,Lantern=true})
check("closed connector excludes unreachable endpoint",c~="Lantern" and d==1)
local tiedGraph={Square={"B","C"},B={"Square"},C={"Square"}}
local t,dd,tt=L.farthest(tiedGraph,{"Square"},nil,{B=true,C=true})
check("lead-choice candidates returned for genuine distance tie",dd==1 and #tt==2 and tt[1]=="B" and tt[2]=="C")
-- Actual Board callback, not only the pure distance helper.
local names={"Square","Milestones","Bridge","Turning","Stair","Lantern","Steps"}
local adjacent={{2,7},{1,3},{2,4},{3,5},{4,6},{5},{1}}
local cards={}
for i,name in ipairs(names) do
 local neighbors={}
 for _,j in ipairs(adjacent[i]) do neighbors[#neighbors+1]=names[j] end
 cards[#cards+1]={guid=name,obj={is_face_down=i>=2 and i<=5,getRotation=function() return {0,180,0} end,getName=function() return name end},side={icons=name,connections=table.concat(neighbors,"|")},pos={x=i==7 and 10 or (i-1)*10,y=1,z=i==7 and 10 or 0}}
end
Board.locationCards=function() return cards end
Board.minicards=function() return {{pos={x=0,y=1,z=0}}} end
local placed
Board.findAppointed=function() return {getGUID=function() return "appointed" end,setPosition=function(pos) placed=pos end,setRotation=function() end} end
Board.refreshAppointedButtons=function() end
check("actual Board manifestation chooses Lantern beyond unrevealed path",Board.appointedCtx().placeAtFarthest() and placed[1]==50)
print("CHECKS "..checks)
