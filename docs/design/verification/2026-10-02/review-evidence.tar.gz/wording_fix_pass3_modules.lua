-- SPOILERS: third-pass independent small fixtures for live campaign modules.
local checked=0
local function check(label,ok) assert(ok,label);checked=checked+1;print("PASS "..label) end
local cache={}
local env=setmetatable({getObjects=function() return {} end,getObjectFromGUID=function() return nil end},{__index=_G})
env.require=function(name)
  if cache[name] then return cache[name] end
  cache[name]=assert(loadfile("src/"..name:gsub("%.","/")..".ttslua","t",env))()
  return cache[name]
end
local CS=env.require("StillHour/CampaignState")
local Locations=env.require("StillHour/Locations")
CS.init(3);CS.setPrologue(true);CS.addPendingYears("sthrbirdie",2);CS.addPendingYears("sthrelias",1)
CS.reset()
check("Prologue handoff clears all pending Years",CS.getPendingYears("sthrbirdie")==0 and CS.getPendingYears("sthrelias")==0)
check("Prologue handoff creates neither scar nor completed loop",CS.getLoopsCompleted()==0 and CS.getDissonance()==0)
CS.addPendingYears("sthrbirdie",2);CS.reset()
check("real-loop pending Years survive until Age",CS.getPendingYears("sthrbirdie")==2 and CS.getLoopsCompleted()==1)
local graph={near={"hidden"},hidden={"near","far"},far={"hidden","furthest"},furthest={"far"}}
local where,d,choices=Locations.farthest(graph,{"near"},nil,{near=true,far=true,furthest=true})
check("unrevealed connector is legal transit to revealed endpoint",where=="furthest" and d==3 and #choices==1)
local _,_,ties=Locations.farthest({a={"b","c"},b={"a"},c={"a"}},{"a"},nil,{b=true,c=true})
check("genuine equal-distance destinations remain explicit ties",#ties==2 and ties[1]=="b" and ties[2]=="c")
local g2={near={},far={"furthest"},furthest={"far"}}
local target=Locations.farthest(g2,{"near"},nil,{near=true,furthest=true})
check("closed/missing connector cannot supply a legal route",target=="near")
local Bag=env.require("StillHour/ChaosBag")
local bag=Bag.new()
local container={getName=function() return "Chaos Bag" end}
local token={getGUID=function() return "test01" end,hasTag=function(t) return t=="StillHourStatic" end}
check("token extraction queues pending reveal",bag.onLeave(container,token) and bag.describe().pending==1)
check("duplicate extraction cannot queue twice",not bag.onLeave(container,token) and bag.describe().pending==1)
check("identified consumption is one-shot",bag.takePendingStatic("test01")=="test01" and bag.takePendingStatic("test01")==nil)
bag.onEnter(container,token);bag.onLeave(container,token);bag.onEnter(container,token)
check("returning an unresolved preview discards pending reveal",bag.takePendingStatic("test01")==nil and bag.describe().pending==0)
bag.onLeave(container,token)
local saved=bag.save();local restored=Bag.new();restored.load(saved)
check("pending reveal survives save/load without duplication",restored.describe().pending==1 and restored.takePendingStatic("test01")=="test01" and restored.takePendingStatic("test01")==nil)
print("INDEPENDENT LIVE MODULE CHECKS: "..checked.." passed")
