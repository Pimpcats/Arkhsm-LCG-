-- Independent designer probe: actual AI/path code, identical graph and seeds.
local R={P={},FX={},G={cfg={},locs={},inv={},enemies={},crossedThisRound={}}}
local T={E={},J={}}
dofile('tools/play_engine/lua/rules.lua')(R,T)
local A=dofile('tools/play_engine/lua/ai.lua')(R,T)
local function loc(id,guid) local L={id=id,guid=guid,district='Square',closed=false,adj={}};R.G.locs[guid]=L;return L end
local s,a,b,d=loc('start','s00001'),loc('equal A','a00001'),loc('equal B','b00001'),loc('goal','d00001')
s.adj[a.guid]=a;s.adj[b.guid]=b;a.adj[s.guid]=s;a.adj[d.guid]=d;b.adj[s.guid]=s;b.adj[d.guid]=d;d.adj[a.guid]=a;d.adj[b.guid]=b
A.targetFor=function() return d end
local inv={id='probe',loc=s.guid}
local function report(label)
 math.randomseed(20261002)
 local random1,random2=math.random(),math.random()
 local move=A.chooseMove(inv,s,true)
 local nextStep,length=R.route(s,d)
 assert(R.canEnter(s,move) and R.canEnter(s,nextStep) and length==2,'illegal route')
 print(string.format('%s move=%s next=%s distance=%d rng=%.10f,%.10f',label,move.id,nextStep.id,length,random1,random2))
end
report('default')
-- __pairs controls only legal equal-neighbor enumeration; all nodes and edges
-- remain identical. This demonstrates the production code's order dependence.
for _,order in ipairs({{a.guid,b.guid},{b.guid,a.guid}}) do
 setmetatable(s.adj,{__pairs=function(t) local i=0;return function() i=i+1;local k=order[i];if k then return k,t[k] end end,t,nil end})
 report('controlled-'..order[1])
end
