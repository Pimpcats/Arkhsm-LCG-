-- Independent post-fix checks of current source, not committed dist artifacts.
-- Cache-only reviewer fixture. No authored/runtime files are modified.
local passed, failed = 0, 0
local function check(name, cond, detail)
  print((cond and "PASS " or "FAIL ") .. name .. (detail and (" | " .. detail) or ""))
  if cond then passed=passed+1 else failed=failed+1 end
end
local function encode(v)
  local t=type(v)
  if t=="number" or t=="boolean" then return tostring(v) end
  if t=="nil" then return "nil" end
  if t=="string" then return string.format("%q",v) end
  if t=="table" then
    local parts={}
    for k,val in pairs(v) do
      local key=type(k)=="number" and ("["..k.."]") or ("["..string.format("%q",k).."]")
      parts[#parts+1]=key.."="..encode(val)
    end
    return "{"..table.concat(parts,",").."}"
  end
  error("unsupported fixture value "..t)
end
local function runtime()
  local modules, objects, buttons, messages = {}, {}, {}, {}
  local env=setmetatable({}, {__index=_G})
  env._G=env
  env.require=function(name)
    if modules[name] then return modules[name] end
    modules[name]=assert(loadfile("src/"..name:gsub("%.","/")..".ttslua","t",env))()
    return modules[name]
  end
  env.JSON={encode=encode,decode=function(s) return assert(load("return "..s,"fixture JSON","t",env))() end}
  env.getObjects=function() return {} end -- virtual bag / no SCED board
  env.getObjectFromGUID=function(g) return objects[g] end
  -- Deterministically flush host scheduling; this fixture checks outcomes,
  -- not real asynchronous timing or object-spawn races.
  env.Wait={frames=function(fn) fn() end,time=function(fn) fn() end}
  env.broadcastToAll=function(s) messages[#messages+1]=s end
  env.print=function(s) messages[#messages+1]=tostring(s) end
  env.self={
    createButton=function(def) buttons[#buttons+1]=def end,
    clearButtons=function() for i=#buttons,1,-1 do buttons[i]=nil end end,
    getPosition=function() return {x=0,y=1,z=0} end,
    getGUID=function() return "control" end,
  }
  assert(loadfile("src/tts/control.lua","t",env))()
  env.onLoad(nil)
  local cs=env.require("StillHour/CampaignState")
  cs.init(3)
  local container={getName=function() return "Chaos Bag" end}
  local function token(g)
    local tokenButtons={}
    local obj={
      getGUID=function() return g end, hasTag=function(tag) return tag=="StillHourStatic" end,
      createButton=function(def) tokenButtons[#tokenButtons+1]=def end,
      clearButtons=function() for i=#tokenButtons,1,-1 do tokenButtons[i]=nil end end,
      getButtons=function() return tokenButtons end,
    }
    objects[g]=obj
    return obj
  end
  return env,cs,container,token,messages,buttons
end
local function state(env) return env.shApiState() end
local function meter(env,d,stage,pending)
  local s=state(env)
  return s.dissonance==d and s.stage==stage and s.static.pending==pending
end

print("== Actual live Control Static entry points ==")
do
  local e,cs,bag,token=runtime()
  cs.setDissonanceRaw(7)
  local a=token("aaa111")
  e.onObjectLeaveContainer(bag,a)
  check("extraction defers all meter/Approach effects",meter(e,7,0,1))
  e.onObjectLeaveContainer(bag,a)
  check("duplicate extraction queues once",meter(e,7,0,1))
  check("explicit cancellation consumes pending token",e.shApiResolveStatic({guid="aaa111",cancel=true}) and meter(e,7,0,0))
  check("duplicate resolution after cancel is inert",not e.shApiResolveStatic({guid="aaa111"}) and meter(e,7,0,0))
  e.onObjectEnterContainer(bag,a)
  e.onObjectLeaveContainer(bag,a)
  e.onObjectEnterContainer(bag,a)
  check("returning outside-test preview is inert",meter(e,7,0,0))
  e.onObjectLeaveContainer(bag,a)
  check("explicit resolution crosses band once",e.shApiResolveStatic({guid="aaa111"}) and meter(e,8,1,0))
  check("duplicate commit is inert",not e.shApiResolveStatic({guid="aaa111"}) and meter(e,8,1,0))
  e.onObjectLeaveContainer(bag,a)
  check("duplicate extraction after commit does not requeue",meter(e,8,1,0))
  e.onObjectEnterContainer(bag,a)
  e.onObjectLeaveContainer(bag,a)
  check("same physical token can be drawn anew after return",meter(e,8,1,1))
end
do
  local e,cs,bag,token,messages=runtime()
  cs.setDissonanceRaw(23)
  cs.advanceAppointed(3)
  local a=token("aaa111")
  e.onObjectLeaveContainer(bag,a)
  local function resetNotice()
    for _,s in ipairs(messages) do if s:find("reached the reset",1,true) then return true end end
    return false
  end
  check("draw at reset boundary does not announce reset",meter(e,23,3,1) and not resetNotice())
  e.shResolveStatic(nil,"White",true)
  check("GUI cancellation at reset boundary is inert",meter(e,23,3,0) and not resetNotice())
  e.onObjectEnterContainer(bag,a)
  e.onObjectLeaveContainer(bag,a)
  e.shResolveStatic(nil,"White",false)
  check("GUI resolution announces reset only after commit",meter(e,24,3,0) and resetNotice())
end
do
  local e,cs,bag,token=runtime()
  cs.setDissonanceRaw(7)
  local a,b=token("aaa111"),token("bbb222")
  e.onObjectLeaveContainer(bag,a)
  e.onObjectLeaveContainer(bag,b)
  check("two separate tokens queue independently",meter(e,7,0,2))
  e.shApiResolveStatic({guid="bbb222",cancel=true})
  e.onObjectEnterContainer(bag,b)
  check("identified cancellation preserves surviving token",e.shApiResolveStatic({guid="aaa111"}) and meter(e,8,1,0))
end
do
  local e,cs,bag,token=runtime()
  cs.setDissonanceRaw(7)
  local a,b=token("aaa111"),token("bbb222")
  e.onObjectLeaveContainer(bag,a)
  e.onObjectLeaveContainer(bag,b)
  -- UI has no token selector: cancel B with the described right-click,
  -- return B physically, then resolve A before continuing its test.
  check("anonymous multi-token cancellation refuses without consuming",not e.shResolveStatic(nil,"White",true) and meter(e,7,0,2))
  check("anonymous multi-token resolution also refuses",not e.shResolveStatic(nil,"White",false) and meter(e,7,0,2))
  e.onObjectEnterContainer(bag,b)
  local committed=e.shResolveStatic(nil,"White",false)
  local s=state(e)
  check("anonymous GUI cancel followed by return preserves other Static",committed and meter(e,8,1,0),
    string.format("commit=%s D=%d stage=%d pending=%d",tostring(committed),s.dissonance,s.stage,s.static.pending))
end
do
  local e,cs,bag,token=runtime()
  cs.setDissonanceRaw(7)
  local a,b=token("aaa111"),token("bbb222")
  e.onObjectLeaveContainer(bag,a)
  e.onObjectLeaveContainer(bag,b)
  local ab,bb=a.getButtons()[1],b.getButtons()[1]
  check("both physical draws receive identified Resolve buttons",ab and bb and ab.click_function=="shResolveStaticToken" and bb.click_function=="shResolveStaticToken")
  e.onObjectLeaveContainer(bag,b)
  check("duplicate extraction does not duplicate physical buttons",#b.getButtons()==1 and meter(e,7,0,2))
  local canceled=bb and e[bb.click_function](b,"White",true)
  check("physical token B cancellation leaves A pending",canceled and meter(e,7,0,1) and #b.getButtons()==0 and #a.getButtons()==1)
  e.onObjectEnterContainer(bag,b)
  local committed=ab and e[ab.click_function](a,"White",false)
  check("physical token A resolution commits exactly its surviving effect",committed and meter(e,8,1,0) and #a.getButtons()==0)
end
do
  local e,cs,bag,token=runtime()
  cs.setDissonanceRaw(7)
  local a=token("aaa111")
  e.onObjectLeaveContainer(bag,a)
  local saved=e.onSave()
  local e2,cs2,bag2,token2=runtime()
  token2("aaa111")
  e2.onLoad(saved)
  check("pending draw survives save/load without resolving",meter(e2,7,0,1))
  check("reloaded pending draw resolves exactly once",e2.shApiResolveStatic({guid="aaa111"}) and not e2.shApiResolveStatic({guid="aaa111"}) and meter(e2,8,1,0))
end
do
  local e,cs,bag,token=runtime()
  cs.setDissonanceRaw(7)
  e.onObjectLeaveContainer(bag,token("aaa111"))
  e.onObjectLeaveContainer(bag,token("bbb222"))
  local saved=e.onSave()
  local e2,cs2,bag2,token2=runtime()
  local a2,b2=token2("aaa111"),token2("bbb222")
  e2.onLoad(saved)
  local ab,bb=a2.getButtons()[1],b2.getButtons()[1]
  check("multiple pending physical-token buttons are restored on load",ab and bb and meter(e2,7,0,2))
  e2.onLoad(saved)
  check("repeat pending restoration does not duplicate buttons",#a2.getButtons()==1 and #b2.getButtons()==1)
  ab,bb=a2.getButtons()[1],b2.getButtons()[1]
  local canceled=bb and e2[bb.click_function](b2,"White",true)
  e2.onObjectEnterContainer(bag2,b2)
  local committed=ab and e2[ab.click_function](a2,"White",false)
  check("restored physical callbacks cancel/resolve correct GUIDs",canceled and committed and meter(e2,8,1,0))
end

print("\n== Actual live Control Prologue and real-loop aging ==")
do
  local e,cs,bag,token=runtime()
  local ids={"sthrelias","sthrayako","sthrseraphine","sthrbirdie","sthrcass"}
  cs.setPrologue(true)
  for i,id in ipairs(ids) do e.shApiPendingYears({id=id,delta=i}) end
  e.onObjectLeaveContainer(bag,token("aaa111"))
  e.shApiReset()
  local cleared=true
  for _,id in ipairs(ids) do cleared=cleared and cs.getPendingYears(id)==0 and cs.getYears(id)==0 end
  check("Prologue reset clears every pending investigator Year",cleared and cs.getLoopsCompleted()==0)
  check("Prologue reset also discards pending Static",state(e).static.pending==0)
  check("Age stays skipped after Prologue",e.shApiAge({id="sthrelias"})==nil and cs.getYears("sthrelias")==0)
  e.shBeginNextLoop()
  e.shApiReset()
  local aged=e.shApiAge({id="sthrelias"})
  check("first real loop gains only its base Year",aged and aged.gained==1 and aged.years==1 and cs.getPendingYears("sthrelias")==0)
  e.shBeginNextLoop()
  e.shApiPendingYears({id="sthrelias",delta=1})
  e.shApiReset()
  check("real-loop reset preserves pending Years for Age",cs.getPendingYears("sthrelias")==1)
  aged=e.shApiAge({id="sthrelias"})
  check("real-loop Age consumes pending Year exactly once",aged and aged.gained==2 and aged.years==3 and cs.getPendingYears("sthrelias")==0)
  check("duplicate Age does not age again",e.shApiAge({id="sthrelias"})==nil and cs.getYears("sthrelias")==3)
end

print("\n== Actual Board destination filtering and lead tie procedure ==")
do
  local e,cs=runtime()
  local board=e.require("StillHour/Board")
  local locations=e.require("StillHour/Locations")
  local names={"Square","Milestones","Bridge","Turning","Stair","Lantern","Steps"}
  local adjacency={{2,7},{1,3},{2,4},{3,5},{4,6},{5},{1}}
  local cards,messages={},{}
  for i,name in ipairs(names) do
    local nbs={}
    for _,j in ipairs(adjacency[i]) do nbs[#nbs+1]=names[j] end
    cards[i]={guid=name,obj={is_face_down=i>=2 and i<=5,getName=function() return name end,getRotation=function() return {0,180,0} end},
      side={icons=name,connections=table.concat(nbs,"|")},pos={x=i==7 and 10 or (i-1)*10,y=1,z=i==7 and 10 or 0}}
  end
  board.locationCards=function() return cards end
  board.minicards=function() return {{pos={x=0,y=1,z=0}}} end
  local pos={0,1,0}
  local appointed={type="Card",getGUID=function() return "appointed" end,getName=function() return "Appointed" end,
    setPosition=function(p) pos=p end,setRotation=function() end,getPosition=function() return pos end,getRotation=function() return {0,180,0} end,
    getGMNotes=function() return encode({id="sthr-appointed",type="Enemy"}) end}
  board.findAppointed=function() return appointed end
  board.refreshAppointedButtons=function() end
  board.init(e.self,{log=function(s) messages[#messages+1]=s end})
  check("manifest uses unrevealed transit to revealed distant endpoint",board.appointedCtx().placeAtFarthest() and pos[1]==50)
  local graph=board.graph(board.movableLocations())
  local best,distance,tied=locations.farthest(graph,{"Square"},nil,{Lantern=true,Steps=true})
  check("destination filter does not remove transit",best=="Lantern" and distance==5 and #tied==1)
  -- Same graph, a second investigator at Lantern: equal-distance Bridge and Turning.
  best,distance,tied=locations.farthest(graph,{"Square","Lantern"},nil,{Bridge=true,Turning=true})
  check("farthest minimizes distance to any investigator",distance==2 and #tied==2)
  -- Two revealed endpoints on equal-length paths; physical layout is irrelevant.
  cards[6].obj.is_face_down=true
  cards[3].obj.is_face_down=false
  cards[4].obj.is_face_down=false
  board.minicards=function() return {{pos={x=0,y=1,z=0}},{pos={x=50,y=1,z=0}}} end
  -- The second investigator's endpoint is now unrevealed, so still a legal transit source.
  board.appointedCtx().placeAtFarthest()
  local announced=false
  for _,s in ipairs(messages) do
    if s:find("Farthest-location tie",1,true) and s:find("Bridge",1,true) and s:find("Turning",1,true) and s:find("lead investigator chooses",1,true) then announced=true end
  end
  check("exact graph tie is announced with both destinations",announced)
  pos={30,1.6,-0.9}
  board.onDrop(appointed)
  check("lead's manual tie choice is remembered",board.save().appointed.lastPos.x==30)
end

print(string.format("\nRESULT %d passed; %d failed",passed,failed))
os.exit(failed==0 and 0 or 1)
